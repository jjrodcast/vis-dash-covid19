Para ejecutar el proyecto web se debe tener instalado

1. Plotly (pip install plotly)
2. Plotly Express (pip install plotly-express)
3. Dash (pip install dash)
4. Pandas (pip install pandas)
5. Numpy (pip install numpy)

Una vez instalado los paquetess necesarios entrar a la carpeta Proyecto-Dash-Covid y ejecutar por comando la instrucción:

python3 app.py
